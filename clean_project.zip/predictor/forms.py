from django import forms

from .constants import IPL_TEAMS


class PredictionForm(forms.Form):
    batting_team = forms.ChoiceField(choices=[(team, team) for team in IPL_TEAMS])
    bowling_team = forms.ChoiceField(choices=[(team, team) for team in IPL_TEAMS])
    current_score = forms.IntegerField(min_value=0, max_value=300)
    wickets_down = forms.IntegerField(min_value=0, max_value=9)
    overs_completed = forms.FloatField(min_value=5.0, max_value=19.5)
    runs_last_five = forms.IntegerField(min_value=0, max_value=100)
    wickets_last_five = forms.IntegerField(min_value=0, max_value=5)

    def clean(self):
        cleaned_data = super().clean()
        batting_team = cleaned_data.get("batting_team")
        bowling_team = cleaned_data.get("bowling_team")
        overs_completed = cleaned_data.get("overs_completed")

        if batting_team and bowling_team and batting_team == bowling_team:
            self.add_error("bowling_team", "Batting and bowling teams must be different.")

        if overs_completed is not None:
            over_fraction = round((overs_completed - int(overs_completed)) * 10)
            if over_fraction > 5:
                self.add_error("overs_completed", "Use cricket overs format like 12.3 or 17.5.")

        return cleaned_data
