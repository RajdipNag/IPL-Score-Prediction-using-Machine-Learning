from __future__ import annotations

import json
import random
import sys
from pathlib import Path

CURRENT_FILE = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_FILE.parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from predictor.constants import IPL_TEAMS

ATTACK_STRENGTH = {
    "Chennai Super Kings": 1.02,
    "Delhi Capitals": 0.98,
    "Gujarat Titans": 1.01,
    "Kolkata Knight Riders": 1.05,
    "Lucknow Super Giants": 1.00,
    "Mumbai Indians": 1.07,
    "Punjab Kings": 1.03,
    "Rajasthan Royals": 1.04,
    "Royal Challengers Bengaluru": 1.06,
    "Sunrisers Hyderabad": 1.02,
}

DEFENSE_STRENGTH = {
    "Chennai Super Kings": 0.97,
    "Delhi Capitals": 1.01,
    "Gujarat Titans": 0.95,
    "Kolkata Knight Riders": 0.98,
    "Lucknow Super Giants": 0.97,
    "Mumbai Indians": 1.03,
    "Punjab Kings": 1.04,
    "Rajasthan Royals": 0.99,
    "Royal Challengers Bengaluru": 1.05,
    "Sunrisers Hyderabad": 0.96,
}

FEATURE_ORDER = [
    "bias",
    "current_score",
    "wickets_down",
    "overs_completed",
    "balls_bowled",
    "balls_remaining",
    "wickets_left",
    "runs_last_five",
    "wickets_last_five",
    "current_run_rate",
    "batting_attack",
    "bowling_defense",
]


def overs_to_balls(overs_completed: float) -> int:
    overs = int(overs_completed)
    balls = round((overs_completed - overs) * 10)
    return (overs * 6) + balls


def engineer_features(row: dict[str, float | int | str]) -> dict[str, float]:
    balls_bowled = overs_to_balls(float(row["overs_completed"]))
    balls_remaining = max(0, 120 - balls_bowled)
    wickets_left = 10 - int(row["wickets_down"])
    current_run_rate = (float(row["current_score"]) * 6 / balls_bowled) if balls_bowled else 0.0

    batting_team = str(row["batting_team"])
    bowling_team = str(row["bowling_team"])

    return {
        "bias": 1.0,
        "current_score": float(row["current_score"]),
        "wickets_down": float(row["wickets_down"]),
        "overs_completed": float(row["overs_completed"]),
        "balls_bowled": float(balls_bowled),
        "balls_remaining": float(balls_remaining),
        "wickets_left": float(wickets_left),
        "runs_last_five": float(row["runs_last_five"]),
        "wickets_last_five": float(row["wickets_last_five"]),
        "current_run_rate": float(current_run_rate),
        "batting_attack": ATTACK_STRENGTH[batting_team],
        "bowling_defense": DEFENSE_STRENGTH[bowling_team],
    }


def build_target(row: dict[str, float | int | str]) -> float:
    features = engineer_features(row)
    projected = (
        28.0
        + features["current_score"] * 0.78
        + features["balls_remaining"] * 0.86
        + features["wickets_left"] * 4.7
        + features["runs_last_five"] * 0.52
        - features["wickets_last_five"] * 5.4
        + features["current_run_rate"] * 3.2
        + features["batting_attack"] * 15.0
        - features["bowling_defense"] * 9.0
    )
    return max(features["current_score"] + 8.0, min(260.0, projected))


def generate_dataset(sample_count: int = 2600) -> list[tuple[dict[str, float], float]]:
    rng = random.Random(42)
    rows: list[tuple[dict[str, float], float]] = []
    for _ in range(sample_count):
        batting_team = rng.choice(IPL_TEAMS)
        bowling_team = rng.choice([team for team in IPL_TEAMS if team != batting_team])
        overs = rng.randint(5, 19)
        balls = rng.randint(0, 5)
        overs_completed = overs + balls / 10
        balls_bowled = overs * 6 + balls
        wickets_down = rng.randint(0, min(8, max(2, balls_bowled // 14)))

        attack = ATTACK_STRENGTH[batting_team]
        defense = DEFENSE_STRENGTH[bowling_team]
        phase_boost = 1 + max(0, balls_bowled - 72) / 100
        run_rate = (7.4 * attack / defense) * phase_boost

        current_score = max(35, int(rng.gauss(run_rate * balls_bowled / 6, 9)))
        runs_last_five = max(20, int(rng.gauss(run_rate * 5, 7)))
        wickets_last_five = rng.randint(0, min(3, wickets_down + 1))

        row = {
            "batting_team": batting_team,
            "bowling_team": bowling_team,
            "current_score": current_score,
            "wickets_down": wickets_down,
            "overs_completed": round(overs_completed, 1),
            "runs_last_five": runs_last_five,
            "wickets_last_five": wickets_last_five,
        }
        noisy_target = build_target(row) + rng.gauss(0, 5)
        final_score = max(current_score + 8.0, min(260.0, noisy_target))
        rows.append((engineer_features(row), final_score))
    return rows


def solve_linear_system(matrix: list[list[float]], vector: list[float]) -> list[float]:
    size = len(vector)
    augmented = [row[:] + [value] for row, value in zip(matrix, vector)]

    for pivot_index in range(size):
        pivot_row = max(range(pivot_index, size), key=lambda row: abs(augmented[row][pivot_index]))
        augmented[pivot_index], augmented[pivot_row] = augmented[pivot_row], augmented[pivot_index]

        pivot = augmented[pivot_index][pivot_index]
        if abs(pivot) < 1e-10:
            pivot = 1e-10
            augmented[pivot_index][pivot_index] = pivot

        for column in range(pivot_index, size + 1):
            augmented[pivot_index][column] /= pivot

        for row in range(size):
            if row == pivot_index:
                continue
            factor = augmented[row][pivot_index]
            for column in range(pivot_index, size + 1):
                augmented[row][column] -= factor * augmented[pivot_index][column]

    return [augmented[row][-1] for row in range(size)]


def solve_linear_regression(samples: list[tuple[dict[str, float], float]]) -> dict[str, float]:
    feature_count = len(FEATURE_ORDER)
    xtx = [[0.0 for _ in range(feature_count)] for _ in range(feature_count)]
    xty = [0.0 for _ in range(feature_count)]
    ridge_penalty = 0.08

    for features, target in samples:
        values = [features[name] for name in FEATURE_ORDER]
        for i in range(feature_count):
            xty[i] += values[i] * target
            for j in range(feature_count):
                xtx[i][j] += values[i] * values[j]

    for index in range(feature_count):
        xtx[index][index] += ridge_penalty

    solved_weights = solve_linear_system(xtx, xty)
    return {name: solved_weights[index] for index, name in enumerate(FEATURE_ORDER)}


def train_and_save_model(output_path: Path) -> Path:
    samples = generate_dataset()
    weights = solve_linear_regression(samples)

    model_payload = {
        "model_name": "Synthetic Linear Regression",
        "feature_order": FEATURE_ORDER,
        "weights": weights,
        "team_strength": {
            "attack": ATTACK_STRENGTH,
            "defense": DEFENSE_STRENGTH,
        },
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(model_payload, indent=2), encoding="utf-8")
    return output_path


if __name__ == "__main__":
    artifact_path = Path(__file__).resolve().parent / "artifacts" / "ipl_score_predictor_model.json"
    train_and_save_model(artifact_path)
    print(f"Saved model artifact to {artifact_path}")
