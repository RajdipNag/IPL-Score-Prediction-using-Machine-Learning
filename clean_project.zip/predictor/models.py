from django.db import models


class PredictionLog(models.Model):
    batting_team = models.CharField(max_length=120)
    bowling_team = models.CharField(max_length=120)
    current_score = models.PositiveIntegerField()
    wickets_down = models.PositiveIntegerField()
    overs_completed = models.DecimalField(max_digits=4, decimal_places=1)
    runs_last_five = models.PositiveIntegerField()
    wickets_last_five = models.PositiveIntegerField()
    predicted_score = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"{self.batting_team} vs {self.bowling_team} - {self.predicted_score}"
