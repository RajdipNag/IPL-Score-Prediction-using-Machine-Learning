from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="PredictionLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("batting_team", models.CharField(max_length=120)),
                ("bowling_team", models.CharField(max_length=120)),
                ("current_score", models.PositiveIntegerField()),
                ("wickets_down", models.PositiveIntegerField()),
                ("overs_completed", models.DecimalField(decimal_places=1, max_digits=4)),
                ("runs_last_five", models.PositiveIntegerField()),
                ("wickets_last_five", models.PositiveIntegerField()),
                ("predicted_score", models.PositiveIntegerField()),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
