from django.db.utils import OperationalError, ProgrammingError
from django.shortcuts import render

from .forms import PredictionForm
from .models import PredictionLog
from .services import predict_score


def home(request):
    result = None
    startup_issue = None

    try:
        recent_predictions = PredictionLog.objects.all()[:5]
    except (OperationalError, ProgrammingError):
        recent_predictions = []
        startup_issue = "Run database migrations to enable saved prediction history."

    if request.method == "POST":
        form = PredictionForm(request.POST)
        if form.is_valid():
            cleaned = form.cleaned_data
            try:
                result = predict_score(cleaned)
                PredictionLog.objects.create(
                    batting_team=cleaned["batting_team"],
                    bowling_team=cleaned["bowling_team"],
                    current_score=cleaned["current_score"],
                    wickets_down=cleaned["wickets_down"],
                    overs_completed=cleaned["overs_completed"],
                    runs_last_five=cleaned["runs_last_five"],
                    wickets_last_five=cleaned["wickets_last_five"],
                    predicted_score=result["predicted_score"],
                )
                recent_predictions = PredictionLog.objects.all()[:5]
            except (OperationalError, ProgrammingError):
                startup_issue = "Prediction worked, but the database table is missing. Run migrations on PythonAnywhere."
            except Exception as exc:
                startup_issue = f"Prediction could not be completed: {exc}"
    else:
        form = PredictionForm(
            initial={
                "batting_team": "Mumbai Indians",
                "bowling_team": "Chennai Super Kings",
                "current_score": 92,
                "wickets_down": 3,
                "overs_completed": 11.2,
                "runs_last_five": 42,
                "wickets_last_five": 1,
            }
        )

    context = {
        "form": form,
        "result": result,
        "recent_predictions": recent_predictions,
        "startup_issue": startup_issue,
    }
    return render(request, "predictor/home.html", context)
