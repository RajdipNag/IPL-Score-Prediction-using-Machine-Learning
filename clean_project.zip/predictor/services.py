from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

from .constants import IPL_TEAMS
from .ml.train_model import FEATURE_ORDER, engineer_features, train_and_save_model

MODEL_DIR = Path(__file__).resolve().parent / "ml" / "artifacts"
MODEL_PATH = MODEL_DIR / "ipl_score_predictor_model.json"


def ensure_model() -> Path:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    if not MODEL_PATH.exists():
        train_and_save_model(MODEL_PATH)
    return MODEL_PATH


def overs_to_balls(overs_completed: float) -> int:
    overs = int(overs_completed)
    balls = round((overs_completed - overs) * 10)
    return (overs * 6) + balls


def build_features(payload: Dict[str, float | int | str]) -> dict[str, float]:
    return engineer_features(
        {
            "batting_team": payload["batting_team"],
            "bowling_team": payload["bowling_team"],
            "current_score": int(payload["current_score"]),
            "wickets_down": int(payload["wickets_down"]),
            "overs_completed": float(payload["overs_completed"]),
            "runs_last_five": int(payload["runs_last_five"]),
            "wickets_last_five": int(payload["wickets_last_five"]),
        }
    )


def predict_score(payload: Dict[str, float | int | str]) -> Dict[str, int]:
    model = json.loads(ensure_model().read_text(encoding="utf-8"))
    features = build_features(payload)
    weights = model["weights"]
    raw_prediction = sum(float(weights[name]) * float(features[name]) for name in FEATURE_ORDER)
    prediction = int(round(raw_prediction))
    current_score = int(payload["current_score"])
    prediction = max(current_score + 8, min(260, prediction))
    lower = max(current_score + 1, prediction - 8)
    upper = max(lower + 4, prediction + 8)
    return {
        "predicted_score": prediction,
        "lower_bound": int(lower),
        "upper_bound": int(upper),
    }
