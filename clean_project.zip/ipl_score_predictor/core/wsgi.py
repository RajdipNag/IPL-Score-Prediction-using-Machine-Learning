import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ipl_score_predictor.core.settings")

application = get_wsgi_application()
